package com.example.myapplication;


import android.os.Bundle;
import android.app.Fragment;
import android.support.v17.leanback.app.BrowseFragment;
import android.support.v17.leanback.widget.ArrayObjectAdapter;
import android.support.v17.leanback.widget.BaseOnItemViewClickedListener;
import android.support.v17.leanback.widget.HeaderItem;
import android.support.v17.leanback.widget.ListRow;
import android.support.v17.leanback.widget.ListRowPresenter;
import android.support.v17.leanback.widget.OnItemViewClickedListener;
import android.support.v17.leanback.widget.Presenter;
import android.support.v17.leanback.widget.Row;
import android.support.v17.leanback.widget.RowPresenter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Toast;

import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class BlankFragment extends BrowseFragment {

    private final static String MainFragmentTAG = "SWiM";
    ArrayObjectAdapter myRowsAdapter;
    public BlankFragment() {
        // Required empty public constructor
    }


    /*@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_blank, container, false);
    }
    */

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Log.i(MainFragmentTAG, "*MainF - onActivityCreated*");
        setupUIElemenet();
        loadRows();
        setupEventsListeners();
    }

    private void setupUIElemenet() {
        setTitle("My first TV App");
        setHeadersState(HEADERS_ENABLED);
        setHeadersTransitionOnBackEnabled(true);
        setBrandColor(getResources().getColor(R.color.lb_browse_header_color));
        setSearchAffordanceColor(getResources().getColor(R.color.lb_default_search_color));
    }
    private void loadRows() {
        int NUM_ROWS = 2;
        myRowsAdapter = new ArrayObjectAdapter(new ListRowPresenter());
        for(int i =0; i <NUM_ROWS; i++)
        {
            HeaderItem gIPH = new HeaderItem(0, "Text Presenter"+i);
            ItemGridPresenter mGP = new ItemGridPresenter();
            ArrayObjectAdapter gRA = new ArrayObjectAdapter(mGP);
            gRA.add("ITEM"+i+1);
            gRA.add("ITEM"+i+2);
            gRA.add("ITEM"+i+3);
            myRowsAdapter.add(new ListRow(gIPH,gRA));
        }

        List<Card> cardList = CardList.buildCardList(getActivity(), 3);
        HeaderItem cPH = new HeaderItem(1, "Moj CardPresenter");
        CardPresenter cardPresenter = new CardPresenter();
        ArrayObjectAdapter cRA = new ArrayObjectAdapter(cardPresenter);
        for(int i = 0; i<3; i++)
            cRA.add(cardList.get(i));

        myRowsAdapter.add(new ListRow(cPH,cRA));
        setAdapter(myRowsAdapter);
    }

    private  void setupEventsListeners()
    {
        setOnSearchClickedListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Implements own search", Toast.LENGTH_SHORT).show();
            }
        });
        setOnItemViewClickedListener(new ItemViewClickListener());
    }


    private final class ItemViewClickListener implements OnItemViewClickedListener
    {


        @Override
        public void onItemClicked(Presenter.ViewHolder viewHolder, Object o, RowPresenter.ViewHolder viewHolder1, Row row) {

            if(o instanceof String) {
                Toast.makeText(getActivity(),((String) o), Toast.LENGTH_SHORT).show();
            }
        }
    }
}
