package com.example.myapplication;

import android.graphics.drawable.Drawable;
import android.support.annotation.StringDef;

public class Card {
    String title;
    String description;
    Drawable image;

    public Card(String title, String description, Drawable image)
    {
        this.description=description;
        this.title=title;
        this.image=image;
    }
}
