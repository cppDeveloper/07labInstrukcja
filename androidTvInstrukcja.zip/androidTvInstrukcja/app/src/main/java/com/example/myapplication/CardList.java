package com.example.myapplication;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class CardList {
    static List<Card> lista;
    private static final int NUMER = 3;
    public static List<Card> buildCardList(Context ctx, int count)
    {
        String title[] =
                {
                        "Tytuł 1",
                        "Tytuł 2",
                        "Tytuł 3"
                };
        String desc[] =
                {
                        "Opis tytułu 1",
                        "Opis tytułu 2",
                        "Opis tytułu 3"

                };
        int[] ids = new int[NUMER];
        ids[0]=R.drawable.img1;
        ids[1]=R.drawable.img2;
        ids[2]=R.drawable.img3;

        if(count>NUMER)
            return null;
        lista= new ArrayList<>();
        for (int idx = 0; idx< NUMER; ++idx)
        {
            Card card = new Card(title[idx],desc[idx], ctx.getResources().getDrawable(ids[idx]));
            lista.add(card);

        }
        return lista;
    }
}
