package com.example.myapplication;

import android.content.Context;
import android.support.v17.leanback.widget.ImageCardView;
import android.support.v17.leanback.widget.Presenter;
import android.util.Log;
import android.view.ViewGroup;

public class CardPresenter extends Presenter {

    private static final String TAG = "TAG1";
    private static  Context mContext;
    private static final int C_WIDTH = 300;
    private static final int C_HEIGHT = 200;
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup) {
        Log.d(TAG, "***onCreateVH  -wywolano***");
        mContext = viewGroup.getContext();
        ImageCardView cardView = new ImageCardView(mContext);
        cardView.setFocusable(true);
        cardView.setFocusableInTouchMode(true);
        cardView.setBackgroundColor(mContext.getResources().getColor(R.color.lb_error_background_color_opaque));


        return new ViewHolder(cardView);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, Object o) {

        Card card = (Card) o;
        ImageCardView cardView  =(ImageCardView) viewHolder.view;
        cardView.setTitleText(card.title);
        cardView.setContentText(card.description);
        cardView.setMainImage(card.image);
        cardView.setMainImageDimensions(C_WIDTH, C_HEIGHT);

    }

    @Override
    public void onUnbindViewHolder(ViewHolder viewHolder) {


        ImageCardView cardView = (ImageCardView) viewHolder.view;
        cardView.setMainImage(null);
    }
}
