package com.example.myapplication;

import android.graphics.Color;
import android.support.v17.leanback.widget.Presenter;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.TextView;

public class ItemGridPresenter extends Presenter {

    private static final int GRID_ITEM_WIDTH = 300;
    private static final int GRID_ITEM_HEIGHT = 200;


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent) {

        TextView v = new TextView(parent.getContext());
        v.setLayoutParams(new ViewGroup.LayoutParams(GRID_ITEM_WIDTH,GRID_ITEM_HEIGHT));
        v.setFocusable(true);
        v.setFocusableInTouchMode(true);
        v.setBackgroundColor(parent.getResources().getColor(R.color.lb_default_brand_color));
        v.setTextColor(Color.WHITE);
        v.setGravity(Gravity.CENTER);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, Object o) {

        ((TextView) viewHolder.view).setText((String) o);


    }

    @Override
    public void onUnbindViewHolder(ViewHolder viewHolder) {

    }
}
